<!-- /* Name: Mohammed Ibrahim
date: 11/6/2023
*/ -->
<?php


$host = 'localhost';
$user = 'root';
$password = '';
$database = 'et';
?>