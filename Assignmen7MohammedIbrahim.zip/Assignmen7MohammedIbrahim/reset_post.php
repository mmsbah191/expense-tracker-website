<!-- /* Name: Mohammed Ibrahim
date: 11/6/2023
The name file is expressive
*/ -->
<?php
session_start();
echo $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/main.css">
    <title>reset</title>
</head>

<body>
    <div class="main">
        <h1>Hellaplus</h1>
        <i>Lorem ipsum dolor sit amet consectetur kldf kldlk dlkl</h5>
            <br><br>
            <h3>login</h3>
            <form action="" class="form">

                <input type="email" name="email" placeholder="email"><br>

                <div class=btn>
                    <button type="submit" name="login">Reset</button><br>
                </div>
            </form>
            <h5>Remembered your password?<a href="index.php">Login now</a></h5>
    </div>
</body>

</html>