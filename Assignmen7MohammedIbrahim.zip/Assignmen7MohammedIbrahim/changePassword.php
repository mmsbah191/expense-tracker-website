<!-- /* Name: Mohammed Ibrahim
date: 11/6/2023
The name file is expressive
*/ -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/main.css">
    <title>reset</title>
</head>

<body>
    <div class="main">
        <?php include('include/logoname.html') ?>

        <h3>Change password</h3>
        <form action="" class="form">

            <input type="password" name="psswrd" placeholder="password" require><br>
            <input type="password" name="psswrd" placeholder="password" required><br>
            <div class=btn>
                <button type="submit" name="login">Reset</button><br>
            </div>
        </form>
        <h5>Remembered your password?<a href="index.php">Login now</a></h5>
    </div>
</body>

</html>